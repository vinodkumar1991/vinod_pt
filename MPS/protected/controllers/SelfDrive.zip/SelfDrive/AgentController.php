<?php

class AgentController extends Controller {

    /**
     * @author Ctel
     * @return string It will succes or fail response
     */
    public function actionCreate() {
        //print_r($_POST);
        $arrResponse = array();
        $intAgentId = 0;
        $objAgent = new SelfDriveForm();
        $objAgent->attributes = $_POST;
   
    
         if ($objAgent->validate()) {
             echo 'in';
            $objectTransaction = Yii::app()->db->beginTransaction();
            $objectDataManager = new DataManager();
            $arrAgent = $objectDataManager->makeData($objAgent->attributes);
         
            $intAgentId = $this->createAgent($arrAgent);
            
            $objectTransaction->rollback();
          exit;
       
           /* $arrResponse = array('type' => Yii::t('app', 'common.ctrl.success'), 
                'data' => $intCustomerId, 'message' => Yii::t('app', 'customer.ctrl.regSuccess'),
                'success' => Yii::t('app', 'common.ctrl.success'), 'customerId' => $intCustomerId
                );*/
        } else {
            echo 'dgjkkhsdk';
           /* $arrResponse = array('type' => Yii::t('app', 'common.ctrl.fail'),
                'data' => $objCustomer->errors, 
                'message' => Yii::t('app', 'customer.ctrl.regFail'), 'success' => Yii::t('app', 'common.ctrl.fail'));*/
        }
        //$this->renderJSON($arrResponse);
    }

    /**
     * @author Ctel
     * @param array $arrCustomer
     * @param integer $intCustomerId
     * @return integer It will return last inserted customer email id
     */
    public function createEmail($arrCustomer, $intCustomerId) {
        $intCustomerEmailId = CustomerEmail::model()->create($arrCustomer, $intCustomerId);
        return $intCustomerEmailId;
    }
    public function createAgent($arrAgentInputs)
    {
        //echo 'dgkjsdkl';
          print_r($arrAgentInputs);
    }
    /**
     * @author Ctel
     * @param array $arrCustomer
     * @param integer $intCustomerId
     * @return integer It will return last inerted phone id
     */
    public function createPhone($arrCustomer, $intCustomerId) {
        $arrCustomer = array_merge($arrCustomer, array('phone_type_id' => 1));
        $intCustomerPhoneId = CustomerPhone::model()->create($arrCustomer, $intCustomerId);
        return $intCustomerPhoneId;
    }

    /**
     * @author Ctel
     * @param array $arrCustomerInput
     * @return integer It will return last inserted customer id
     */
    public function createCustomer($arrCustomerInput) {
        
        print_r($arrCustomerInput);
        /*$intCustomerId = 0;
        if (isset($arrCustomerInput['password'])) {
            $arrCustomerInput['password'] = CommonFunctions::generatePassword($arrCustomerInput['password']);
        }
        $intCustomerId = Customer::model()->create($arrCustomerInput);
        return $intCustomerId;*/
    }

    /**
     * @author Ctel
     * @param integer $intCustomerId
     * @return string It will return verfication code
     */
    public function createVerificationCode($intCustomerId) {
        $objectDataManager = new DataManager();
        $arrVerfication = $objectDataManager->getVerificationCode();
        $intUpdate = Customer::model()->updateCustomer($arrVerfication, $intCustomerId);
        return $arrVerfication['verify_token'];
    }

    /**
     * @author Ctel
     * @return string It will succes or fail response
     */
    public function actionVerify() {
        $strSMSToken = NULL;
        $objVerifcation = new VerificationForm();
        $objVerifcation->attributes = $_POST;
        if ($objVerifcation->validate()) {
            $arrSmsData = Yii::app()->params['sms'];
            //$arrSmsData = array_merge($arrSmsData, array('otp' => '065240','mobile' => '9705999270'));
            $arrSmsData = array_merge($arrSmsData, $objVerifcation->attributes);
            $objectSMSManager = new SMSManager($arrSmsData);
            $strSMSToken = $objectSMSManager->fireSMS();
            $objectTransaction = Yii::app()->db->beginTransaction();
            $intUpdate = Customer::model()->updateCustomer(array('status' => 1, 'sms_token' => $strSMSToken), $intCustomerId = 16);
            if (!empty($intUpdate)) {
                $objectTransaction->commit();
            } else {
                $objectTransaction->rollback();
            }
            $arrResponse = array('type' => Yii::t('app', 'common.ctrl.success'), 'data' => $intUpdate, 'message' => Yii::t('app', 'customer.ctrl.verSuccess'), 'success' => Yii::t('app', 'common.ctrl.success'));
        } else {
            $arrResponse = array('type' => Yii::t('app', 'common.ctrl.fail'), 'data' => $objVerifcation->errors, 'message' => Yii::t('app', 'customer.ctrl.verFail'), 'success' => Yii::t('app', 'common.ctrl.fail'));
        }
        $this->renderJSON($arrResponse);
    }

}
